<h4
    <?php echo e($attributes->class(['fi-ta-empty-state-heading text-base font-semibold leading-6 text-gray-950 dark:text-white'])); ?>

>
    <?php echo e($slot); ?>

</h4>
<?php /**PATH D:\dev\source\kominfo\ppid-konawe\vendor\filament\tables\resources\views/components/empty-state/heading.blade.php ENDPATH**/ ?>