<div
    <?php echo e($attributes->class([
            'fi-ta-ctn divide-y divide-gray-200 overflow-hidden rounded-xl bg-white shadow-sm ring-1 ring-gray-950/5 dark:divide-white/10 dark:bg-gray-900 dark:ring-white/10',
        ])); ?>

>
    <?php echo e($slot); ?>

</div>
<?php /**PATH D:\dev\source\kominfo\ppid-konawe\vendor\filament\tables\resources\views/components/container.blade.php ENDPATH**/ ?>