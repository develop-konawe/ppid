<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($paginator->hasPages()): ?>
    <div class="bg-slate-50 px-4 py-3 border-t border-slate-200">
        <div class="flex flex-col md:flex-row justify-between items-center gap-3">
            <p class="text-sm text-slate-600">
                Menampilkan <span class="font-medium"><?php echo e($paginator->firstItem()); ?></span> - <span class="font-medium"><?php echo e($paginator->lastItem()); ?></span> dari <span class="font-medium"><?php echo e($paginator->total()); ?></span> informasi dikecualikan
            </p>
            <div class="flex gap-2">

                
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($paginator->onFirstPage()): ?>
                    <button class="w-8 h-8 bg-white border border-slate-200 rounded flex items-center justify-center text-slate-400 opacity-50 cursor-not-allowed" disabled>
                        <i class="fa-solid fa-chevron-left text-xs"></i>
                    </button>
                <?php else: ?>
                    <a href="<?php echo e($paginator->previousPageUrl()); ?>" class="w-8 h-8 bg-white border border-slate-200 rounded flex items-center justify-center text-slate-600 hover:bg-exclusive hover:text-white transition-soft">
                        <i class="fa-solid fa-chevron-left text-xs"></i>
                    </a>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(is_string($element)): ?>
                        <span class="w-8 h-8 bg-white border border-slate-200 rounded flex items-center justify-center text-slate-400 text-sm cursor-default">
                            <?php echo e($element); ?>

                        </span>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                    
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(is_array($element)): ?>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($page == $paginator->currentPage()): ?>
                                <button class="w-8 h-8 bg-exclusive text-white rounded text-sm font-semibold cursor-default" aria-current="page">
                                    <?php echo e($page); ?>

                                </button>
                            <?php else: ?>
                                <a href="<?php echo e($url); ?>" class="w-8 h-8 bg-white border border-slate-200 rounded flex items-center justify-center text-slate-600 text-sm hover:bg-exclusive hover:text-white transition-soft">
                                    <?php echo e($page); ?>

                                </a>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($paginator->hasMorePages()): ?>
                    <a href="<?php echo e($paginator->nextPageUrl()); ?>" class="w-8 h-8 bg-white border border-slate-200 rounded flex items-center justify-center text-slate-600 hover:bg-exclusive hover:text-white transition-soft">
                        <i class="fa-solid fa-chevron-right text-xs"></i>
                    </a>
                <?php else: ?>
                    <button class="w-8 h-8 bg-white border border-slate-200 rounded flex items-center justify-center text-slate-400 opacity-50 cursor-not-allowed" disabled>
                        <i class="fa-solid fa-chevron-right text-xs"></i>
                    </button>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        </div>
    </div>
<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
<?php /**PATH D:\dev\source\kominfo\ppid-konawe\resources\views/layouts/pagination/dikecualikan.blade.php ENDPATH**/ ?>