<section id="footer" class="pt-5 pb-5 bg_black">
    <div class="container-xl">
        <div class="row row-cols-1 row-cols-md-4 row-cols-lg-4">
            <div class="col">
                <div class="footer_left">
                    <b class="fs-4  d-block text-uppercase text-white center_sm"> <i class="fa-brands fa-nfc-directional col_yellow me-1"></i> PPID Kabupaten Konawe</b>
                    <p class="gray_dark mt-3">Pusat layanan informasi publik Kabupaten Konawe. Kami berkomitmen memberikan akses informasi yang transparan, cepat, dan akurat sesuai dengan Undang-Undang Keterbukaan Informasi Publik.</p>
                    <p class="gray_dark">PPID Konawe Konawe hadir untuk melayani hak Anda atas informasi.</p>


                </div>
            </div>
            <div class="col">
                <div class="footer_left">
                    <b class="text-uppercase text-white font_13 d-block mb-4 mt-2 center_sm">Contact Info</b>
                    <ul class="mb-0 d-flex social mt-3">
                        @if($socialMediaFooter)
                            @foreach($socialMediaFooter as $social)
                                <li class="ms-2">
                                    <a class="d-block rounded-circle text-center text-white link" href="{{ $social->url }}" title="{{ $textStatement[$social->platform] }}" target="_blank">
                                        <i class="fa-brands {{ $social->icon }}"></i>
                                    </a>
                                </li>
                            @endforeach
                        @endif
                    </ul>
                </div>
            </div>
            <div class="col col-md-6 col-lg-6">
                <div class="footer_left">
                    <div class="ratio ratio-21x9">
                        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d8072.718309058102!2d122.03732516027955!3d-3.8551011638306454!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2d98488b9e8ad733%3A0x6587df9ffbfe4ffa!2sKantor%20Bupati%20Konawe!5e0!3m2!1sid!2sid!4v1756773986492!5m2!1sid!2sid" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>

                    </div>
{{--                    <b class="text-uppercase text-white font_13 d-block mb-4 mt-2 center_sm">Lokasi</b>--}}
                </div>
            </div>
        </div>
    </div>
</section>
