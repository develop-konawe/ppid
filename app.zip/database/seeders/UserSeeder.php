<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        User::create([
            'name' => 'admin',
            'email' => 'ppid_admin@gmail.com',
            'password' => '12345678',
            'is_super_admin' => true,
        ]);

        User::create([
            'name' => 'RSUD Konawe',
            'email' => 'rsud_admin@gmail.com',
            'password' => '12345678',
            'is_super_admin' => false,
        ]);
    }
}
