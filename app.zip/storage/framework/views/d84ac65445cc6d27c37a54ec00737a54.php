<div class="news_1_left1 p-3 bg-white border_thick">
    <div class="news_1_left1_inner row">
        <div class="col-md-3 col-sm-4">
            <div class="news_1_left1_inner_left pt-1">
                <b class="d-block text-uppercase"><i class="fa fa-award fs-3"></i> Kabar Unggulan</b>
            </div>
        </div>
        <div class="col-md-9 col-sm-8">
            <div class="news_1_left1_inner_right">
                <ul class="nav nav-tabs mb-0 fw-bold font_11 border-0 justify-content-end">
                    <li class="nav-item d-inline-block">
                        <a href="#home" data-bs-toggle="tab" aria-expanded="false" class="nav-link active text-center">
                            <span class="d-md-block text-uppercase">Semua</span>
                        </a>
                    </li>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($beritas->isNotEmpty()): ?>
                    <li class="nav-item d-inline-block">
                        <a href="#berita" data-bs-toggle="tab" aria-expanded="true" class="nav-link text-center">
                            <span class="d-md-block text-uppercase">Berita</span>
                        </a>
                    </li>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($pengumumans && $pengumumans->isNotEmpty()): ?>
                        <li class="nav-item d-inline-block">
                            <a href="#pengumuman" data-bs-toggle="tab" aria-expanded="true" class="nav-link border-end-0 text-center">
                                <span class="d-md-block text-uppercase">Pengumuman</span>
                            </a>
                        </li>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                </ul>
            </div>
        </div>
    </div>
</div>

<div class="news_1_left2 mt-3">
    <?php if($beritas->isNotEmpty() || $pengumumans->isNotEmpty()): ?>

        <div class="tab-content">
        
        <div class="tab-pane active" id="home">
            <div id="carouselHomeCaptions" class="carousel slide" data-bs-ride="carousel">
                <div class="carousel-indicators">
                    <?php $jumlahPengumuman = ($pengumumans) ? $pengumumans->count() : 0; ?>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php for($i = 0; $i < ($beritas->count() + $jumlahPengumuman); $i++): ?>
                        <button type="button" data-bs-target="#carouselHomeCaptions" data-bs-slide-to="<?php echo e($i); ?>" class="<?php echo e($i == 0 ? 'active' : ''); ?>" aria-label="Slide 1"></button>
                    <?php endfor; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                </div>
                <div class="carousel-inner">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $beritas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $berita): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="carousel-item <?php echo e($key == 0 ? 'active' : ''); ?>">
                            <div class="news_1_left2_inner position-relative">
                                <div class="news_1_left2_inner1">
                                    
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(file_exists(public_path('storage/'.$berita->image))): ?>
                                        <a href="<?php echo e(route('news.detail', $berita->slug)); ?>"><img src="<?php echo e(asset('storage/' . $berita->image)); ?>" class="img-fluid" alt="abc"></a>
                                    <?php elseif(file_exists(public_path($berita->image))): ?>
                                        <a href="<?php echo e(route('news.detail', $berita->slug)); ?>"><img src="<?php echo e(asset($berita->image)); ?>" class="img-fluid" alt="..."></a>
                                    <?php else: ?>
                                        <a href="<?php echo e(route('news.detail', $berita->slug)); ?>"><img src="<?php echo e(asset('style/image/28.jpg')); ?>" class="img-fluid" alt="..."></a>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    
                                </div>
                                <div class="news_1_left2_inner2 position-absolute bottom-0 px-4 bg_back w-100 h-100 top-0">
                                    <ul class="mb-0">
                                        <li class="d-flex">
			   <span class="flex-column">
                   <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($berita->category_id): ?>
                       <b class="d-inline-block bg_yellow text-white p-1 px-3 font_10 text-uppercase rounded-1"><?php echo e($berita->category->name); ?></b>
                   <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
				 <b class="d-block fs-2 text-uppercase mt-2 mb-2"><a class="text-white" href="<?php echo e(route('news.detail', $berita->slug)); ?>"><?php echo e($berita->title); ?></a></b>
				 <span class="text-light font_11 fw-bold  text-uppercase"><i class="fa fa-user"></i> Admin - <?php echo e($berita->created_at->format('M d, Y')); ?></span>
			   </span>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $pengumumans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $pengumuman): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="carousel-item <?php echo e(($beritas->isEmpty() && $key == 0) ? 'active' : ''); ?>">
                            <div class="news_1_left2_inner position-relative">
                                <div class="news_1_left2_inner1">
                                    
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(file_exists(public_path('storage/'.$pengumuman->image))): ?>
                                        <a href="<?php echo e(route('announcement.detail', $pengumuman->slug)); ?>"><img src="<?php echo e(asset('storage/' . $pengumuman->image)); ?>" class="img-fluid" alt="abc"></a>
                                    <?php elseif(file_exists(public_path($pengumuman->image))): ?>
                                        <a href="<?php echo e(route('announcement.detail', $pengumuman->slug)); ?>"><img src="<?php echo e(asset($pengumuman->image)); ?>" class="img-fluid" alt="..."></a>
                                    <?php else: ?>
                                        <a href="<?php echo e(route('announcement.detail', $pengumuman->slug)); ?>"><img src="<?php echo e(asset('style/image/28.jpg')); ?>" class="img-fluid" alt="..."></a>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    
                                </div>
                                <div class="news_1_left2_inner2 position-absolute bottom-0 px-4 bg_back w-100 h-100 top-0">
                                    <ul class="mb-0">
                                        <li class="d-flex">
                                       <span class="flex-column">
                                         <b class="d-inline-block bg_yellow text-white p-1 px-3 font_10 text-uppercase rounded-1">Popular</b>
                                         <b class="d-block fs-2 text-uppercase mt-2 mb-2"><a class="text-white" href="<?php echo e(route('announcement.detail', $pengumuman->slug)); ?>"><?php echo e($pengumuman->title); ?> </a></b>
                                         <span class="text-light font_11 fw-bold  text-uppercase"><i class="fa fa-user"></i> Admin - <?php echo e($pengumuman->published_at->format('M d, Y')); ?></span>
                                       </span>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                </div>
            </div>
        </div>

        
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($beritas && $beritas->count() > 0): ?>
        <div class="tab-pane" id="berita">
            <div id="carouselBeritaCaptions" class="carousel slide" data-bs-ride="carousel">
                <div class="carousel-indicators">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php for($i = 0; $i < $beritas->count(); $i++): ?>
                        <button type="button" data-bs-target="#carouselBeritaCaptions" data-bs-slide-to="<?php echo e($i); ?>" class="<?php echo e($i == 0 ? 'active' : ''); ?>" aria-label="Slide <?php echo e(($i + 1)); ?>"></button>
                    <?php endfor; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>


                </div>
                <div class="carousel-inner">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $beritas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $berita): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="carousel-item <?php echo e($key == 0 ? 'active' : ''); ?>">
                            <div class="news_1_left2_inner position-relative">
                                <div class="news_1_left2_inner1">
                                    
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(file_exists(public_path('storage/'.$berita->image))): ?>
                                        <a href="<?php echo e(route('news.detail', $berita->slug)); ?>"><img src="<?php echo e(asset('storage/' . $berita->image)); ?>" class="img-fluid" alt="abc"></a>
                                    <?php elseif(file_exists(public_path($berita->image))): ?>
                                        <a href="<?php echo e(route('news.detail', $berita->slug)); ?>"><img src="<?php echo e(asset($berita->image)); ?>" class="img-fluid" alt="..."></a>
                                    <?php else: ?>
                                        <a href="<?php echo e(route('news.detail', $berita->slug)); ?>"><img src="<?php echo e(asset('style/image/28.jpg')); ?>" class="img-fluid" alt="..."></a>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    
                                </div>
                                <div class="news_1_left2_inner2 position-absolute bottom-0 px-4 bg_back w-100 h-100 top-0">
                                    <ul class="mb-0">
                                        <li class="d-flex">
			   <span class="flex-column">
			     <b class="d-inline-block bg_yellow text-white p-1 px-3 font_10 text-uppercase rounded-1">Trending</b>
				 <b class="d-block fs-2 text-uppercase mt-2 mb-2"><a class="text-white" href="news_detail.html"><?php echo e($berita->title); ?></a></b>
				 <span class="text-light font_11 fw-bold  text-uppercase"><img src="<?php echo e(asset('style')); ?>/image/8.jpg" class="me-2 rounded-circle" alt="abc"> Admin - <?php echo e($berita->created_at->format('M d, Y')); ?></span>
			   </span>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
            </div>
        </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($pengumumans && $pengumumans->count() > 0): ?>
        <div class="tab-pane" id="pengumuman">
            <div id="carouselExampleCaptions3" class="carousel slide" data-bs-ride="carousel">
                <div class="carousel-indicators">
                    <button type="button" data-bs-target="#carouselExampleCaptions3" data-bs-slide-to="0" class="active" aria-label="Slide 1"></button>
                    <button type="button" data-bs-target="#carouselExampleCaptions3" data-bs-slide-to="1" aria-label="Slide 2" class="" aria-current="true"></button>
                </div>
                <div class="carousel-inner">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $pengumumans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $pengumuman): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="carousel-item <?php echo e($key == 0 ? 'active' : ''); ?>">
                            <div class="news_1_left2_inner position-relative">
                                <div class="news_1_left2_inner1">
                                    <a href="<?php echo e(route('news.detail', $pengumuman->slug)); ?>"><img src="<?php echo e(asset('storage/' . $pengumuman->image)); ?>" class="img-fluid" alt="abc"></a>
                                </div>
                                <div class="news_1_left2_inner2 position-absolute bottom-0 px-4 bg_back w-100 h-100 top-0">
                                    <ul class="mb-0">
                                        <li class="d-flex">
                                           <span class="flex-column">
                                             <b class="d-inline-block bg_yellow text-white p-1 px-3 font_10 text-uppercase rounded-1">Popular</b>
                                             <b class="d-block fs-2 text-uppercase mt-2 mb-2"><a class="text-white" href="news_detail.html"><?php echo e($pengumuman->title); ?> </a></b>
                                             <span class="text-light font_11 fw-bold  text-uppercase"><img src="<?php echo e(asset('style')); ?>/image/9.jpg" class="me-2 rounded-circle" alt="abc"> Admin - <?php echo e($berita->created_at->format('M d, Y')); ?></span>
                                           </span>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
            </div>
        </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    </div>

    <?php else: ?>
        <div class="row row-cols-1 row-cols-lg-1 row-cols-md-1">
            <div class="col">
                <div class="card">
                    <div class="card-body p-0">
                        <div class="blog_2">
                            <p class="fs-4 mt-3 px-3 mb-0 pb-4">Belum ada data kabar unggulan</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
</div>
<?php /**PATH D:\dev\source\kominfo\ppid-konawe\resources\views/pages/home/partials/home_featured_news.blade.php ENDPATH**/ ?>