<section id="footer_bottom" class="bg-dark">
    <div class="container-fluid p-0">
        <div class="row mx-0">
            <div class="col-md-2 p-0">
                <div class="footer_bottom_left bg_yellow p-4 position-relative">

                </div>
            </div>
            <div class="col-md-8 p-0">
                <div class="footer_bottom_center">








                </div>
            </div>
            <div class="col-md-2 p-0">
                <div class="footer_bottom_right bg_yellow p-4 position-relative">

                </div>
            </div>
        </div>
    </div>
</section>
<?php /**PATH D:\dev\source\kominfo\ppid-konawe\resources\views/layouts/part/footer-bottom.blade.php ENDPATH**/ ?>