<?php use Illuminate\Support\Facades\Storage; ?>

<?php $__env->startPush('style'); ?>
    <style>
        .ppid-hero-banner {
            height: 100vh;
            background-color: #000;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .ppid-hero-banner img {
            transition: all 0.3s ease;
            object-position: center;
            background-color: #000;
            height: 100vh;
            width: auto;
            object-fit: contain;
        }
    </style>
<?php $__env->stopPush(); ?>


<section id="center" class="center_home">
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($banners && $banners->isNotEmpty()): ?>
        <div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="carousel">
            <div class="carousel-inner">
    

                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="carousel-item <?php echo e($key == 0 ? 'active' : ''); ?>" data-bs-interval="3000">
                        <div class="row ppid-hero-banner">
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(Storage::disk('public')->exists($banner->image)): ?>
                                <img id="ppid-hero-image" src="<?php echo e(asset('storage/' . $banner->image)); ?>" loading="lazy" class="d-block " alt="<?php echo e($banner->title); ?>" >
                            <?php else: ?>
                                <img src="<?php echo e(asset('image/1.jpg')); ?>" loading="lazy" class="d-block img-fluid" alt="<?php echo e($banner->title); ?>">
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
            </button>
        </div>

    <?php else: ?>
        <div class="m-4">
        <div class="row row-cols-1 row-cols-lg-1 row-cols-md-1">
            <div class="col mb-4">
                <div class="card">
                    <div class="card-body p-0">
                        <div class="blog_2">
                            <p class="fs-4 mt-3 px-3 mb-0 pb-4">Belum ada banner terbaru</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
</section>
<?php /**PATH D:\dev\source\kominfo\ppid-konawe\resources\views/pages/home/partials/home_banner.blade.php ENDPATH**/ ?>