<?php use Illuminate\Support\Str; ?>

<?php $__env->startPush('styles'); ?>

<?php $__env->stopPush(); ?>
<?php

$bgStyle = [
    'facebook' => 'background: #4c66a4; background: linear-gradient(45deg, #4c66a4, #3b5998, #192f6a);',
    'x' => 'background: #000000; background: linear-gradient(45deg, #000000, #010101, #010101);',
    'instagram' => 'background: #d6249f; background: radial-gradient(circle at 30% 107%, #fdf497 0%, #fdf497 5%, #fd5949 45%,#d6249f 60%,#285AEB 90%);',
    'tiktok' => 'background: #000000; background: linear-gradient(45deg, #000000, #010101, #010101);',
    'youtube' => 'background: #FF0000; background: linear-gradient(45deg, #FF0000, #cc0000, #990000);',
    'threads' => 'background: #000000; background: linear-gradient(45deg, #000000, #010101, #010101);',
];

$textStatement = [
    'facebook' => 'Like Our Facebook Page',
    'x' => 'Follow Us On X',
    'instagram' => 'Follow Us On Instagram',
    'tiktok' => 'Follow Us On TikTok',
    'youtube' => 'Subscribe To Our YouTube Channel',
    'threads' => 'Follow Us On Threads',
];

?>
<div class="news_1_right1">
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($socialMedias): ?>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $socialMedias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $socialMedia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php ($bgIconColorClass = $bgIconColor[$socialMedia->platform] ?? 'bg_black'); ?>
            <?php ($bgStyleClass = $bgStyle[$socialMedia->platform] ?? 'background: #000000; background: linear-gradient(45deg, #000000, #010101, #010101);'); ?>

            <ul class="mb-0 bg-primary d-flex justify-content-between mb-3">
                <li>
                    <a style="<?php echo e($bgStyleClass); ?>" class="social_icon d-inline-block text-center text-white" href="<?php echo e($socialMedia->url); ?>" target="_blank">
                        <i class="fa-brands <?php echo e($socialMedia->icon); ?>"></i>
                    </a>
                </li>
                <li class="lh-1 pt-3 text-uppercase">
                    <a class="text-white" href="<?php echo e($socialMedia->url); ?>" target="_blank">
                      <span class="font_13">
                      <b><?php echo e($textStatement[$socialMedia->platform]); ?> </b><br>
                      
                      </span>
                    </a></li>
                <li class="pt-3 pe-3">
                    
                </li>
            </ul>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
</div>
<?php /**PATH D:\dev\source\kominfo\ppid-konawe\resources\views/pages/home/partials/home_sidebar_social_media.blade.php ENDPATH**/ ?>