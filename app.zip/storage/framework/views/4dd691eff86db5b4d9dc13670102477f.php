<?php $__env->startSection('title', 'Beranda'); ?>

<?php $__env->startPush('style'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <!-- banner start -->
    <?php echo $__env->make('pages.home.partials.home_banner', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <!-- news start -->
    <section id="news" class="pt-5 pb-5 bg-light">
        <div class="container-xl">
            <div class="row news_1">

                
                <div class="col-md-8">
                    <div class="news_1_left">

                        
                        <?php echo $__env->make('pages.home.partials.home_featured_news', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                        

                        
                        <?php echo $__env->make('pages.home.partials.home_latest_news', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                        
                        <?php echo $__env->make('pages.home.partials.home_latest_announcements', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                        
                        <?php echo $__env->make('pages.home.partials.home_gallery', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </div>
                </div>

                
                <div class="col-md-4">
                    <div class="news_1_right">
                        
                        <?php echo $__env->make('pages.home.partials.home_sidebar_social_media', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                        
                        <?php echo $__env->make('pages.home.partials.home_sidebar_popular_news', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                        
                        <?php echo $__env->make('pages.home.partials.home_sidebar_popular_announcements', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                        
                        
                    </div>
                </div>

            </div>
        </div>
    </section>
    <!-- news end -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\dev\source\kominfo\ppid-konawe\resources\views/pages/home/index.blade.php ENDPATH**/ ?>