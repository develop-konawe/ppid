<div class="news_1_right1 bg-white mt-3 border_light">
    <b class="d-block text-uppercase p-3 border_thick">Pengumuman Populer</b>
    <ul class="mb-0 border-top pt-3">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($popularPengumumans && $popularPengumumans->isNotEmpty()): ?>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $popularPengumumans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pengumuman): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="d-flex border-bottom  pb-3 mb-3">
                <span class="ps-3 align-items-center d-flex">
                    <a href="<?php echo e(route('news.detail', $pengumuman->slug)); ?>">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(file_exists(public_path('storage/'.$pengumuman->image))): ?>
                            <img width="70"  src="<?php echo e(asset('storage/' . $pengumuman->image)); ?>" alt="abc">
                        <?php elseif(file_exists(public_path($pengumuman->image))): ?>
                            <img width="70"  src="<?php echo e(asset($pengumuman->image)); ?>" alt="...">
                        <?php else: ?>
                            <img width="70" alt="abc"  src="<?php echo e(asset('style')); ?>/image/20.jpg">
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </a>
                </span>

                <span class="flex-column mx-3">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($pengumuman->category_id): ?>
                        <b class="d-inline-block bg_violet text-white p-1 px-3 font_10 text-uppercase rounded-1"><?php echo e($pengumuman->category->name); ?></b>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    <b class="d-block font_13 text-uppercase mt-1"><a href="<?php echo e(route('news.detail', $pengumuman->slug)); ?>"><?php echo e($pengumuman->title); ?></a></b>
                    <span class="light_gray font_10 fw-bold  text-uppercase"> <i class="fa fa-clock me-1 text-warning align-middle"></i> Aug 13, 2016</span>
                </span>
            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <?php else: ?>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </ul>
</div>
<?php /**PATH D:\dev\source\kominfo\ppid-konawe\resources\views/pages/home/partials/home_sidebar_popular_announcements.blade.php ENDPATH**/ ?>