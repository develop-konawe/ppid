<?php $__env->startSection('title', 'Regulasi'); ?>

<?php $__env->startPush('style'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <section id="contact" class="bg-light">
        <div class="container-fluid p-0">
            <div class="row mx-0">
                <div class="col-md-2 p-0">
                    <div class="footer_bottom_left contact_left text-xl-end p-3 position-relative">
                        <span class="text-white fs-6 fw-bold ms-5">Regulasi</span>
                    </div>
                </div>
                <div class="col-md-10 p-0">
                    <div class="contact_righto  p-3 bg-white">
                        <span class="mb-0 font_11 light_gray"><a class="fw-bold" href="<?php echo e(route("home")); ?>">Beranda</a> <span class="mx-2">/</span> Regulasi</span>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <section id="news" class="pt-5 pb-5 bg-light">
        <div class="container-xl">
            <div class="row">
            <div class="col table-responsive">
                <table class="table table-bordered table-info border-primary">
                    <thead class="table-dark">
                        <tr>
                            <td>No</td>
                            <td>Judul</td>
                            <td>File</td>
                            <td>Tanggal Upload</td>
                            <td>Keterangan</td>
                        </tr>
                    </thead>
                    <tbody>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $listRegulasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $regulasi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            
                            <td>
                                <?php echo e(($listRegulasi->currentPage() - 1) * $listRegulasi->perPage() + $loop->iteration); ?>

                            </td>
                            <td><?php echo e($regulasi->title); ?></td>
                            <td>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($regulasi->doc_url): ?>
                                    <a href="<?php echo e(asset('storage/' . $regulasi->doc_url)); ?>" target="_blank" class="btn btn-sm btn-primary">Download</a>
                                <?php else: ?>
                                    No File
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </td>
                            <td><?php echo e($regulasi->issue_date->translatedFormat('d F Y')); ?></td>
                            <td><?php echo e($regulasi->summary); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="5" class="text-center">Tidak ada data</td>
                        </tr>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </tbody>

                </table>
            </div>
        </div>

            <div class="mt-4 text-center">
                <?php echo e($listRegulasi->links('layouts.pagination.index')); ?>

            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\dev\source\kominfo\ppid-konawe\resources\views/pages/regulation/index.blade.php ENDPATH**/ ?>