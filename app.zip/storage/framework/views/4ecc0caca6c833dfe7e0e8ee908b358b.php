
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Favicon dan App Icons -->
    <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(asset('image/icon/apple-touch-icon.png')); ?>">
    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset('image/icon/favicon-32x32.png')); ?>">
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('image/icon/favicon-16x16.png')); ?>">
    <link rel="icon" href="<?php echo e(asset('image/icon/favicon.ico')); ?>">
    <link rel="manifest" href="<?php echo e(asset('image/icon/site.webmanifest')); ?>">
    <meta name="theme-color" content="#ffffff">

    
    <title><?php echo $__env->yieldContent('title'); ?></title>

    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>

    <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">

    <?php echo $__env->yieldPushContent('style'); ?>
</head>
<body>
    <?php
        $socialMediaHeadMenu = \App\Models\SocialMedia::take(3)->get();
        $socialMediaFooter = \App\Models\SocialMedia::all();
        $textStatement = [
            'facebook' => 'Like Our Facebook Page',
            'x' => 'Follow Us On X',
            'instagram' => 'Follow Us On Instagram',
            'tiktok' => 'Follow Us On TikTok',
            'youtube' => 'Subscribe To Our YouTube Channel',
            'threads' => 'Follow Us On Threads',
        ];
    ?>

    
    
    <?php echo $__env->make('layouts.part.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php echo $__env->yieldContent('content'); ?>

    <?php echo $__env->make('layouts.part.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('layouts.part.footer-bottom', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php echo app('Illuminate\Foundation\Vite')('resources/js/app.js'); ?>
    <script src="<?php echo e(asset('style/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('style/js/theme.min.js')); ?>"></script>
    <?php echo $__env->yieldPushContent('scripts'); ?>

    <script src="https://cdn.jsdelivr.net/npm/sienna-accessibility@latest/dist/sienna-accessibility.umd.js" defer></script>
</body>
</html>
<?php /**PATH D:\dev\source\kominfo\ppid-konawe\resources\views/layouts/app.blade.php ENDPATH**/ ?>