<?php
    $currentRoute = request()->route()->getName();

    $menus = \App\Models\Menu::with('children')
        ->whereNull('parent_id')
//        ->where('is_active', true)
        ->orderBy('order')
        ->get();

    // ambil 3 data pertama
?>
<section id="header">
    <nav class="navbar navbar-expand-lg navbar-light w-100 justify-content-start">
        <div class="container-xxl mx-3" style="margin-left: 0">
            <a class="d-flex text-white" href="<?php echo e(route('home')); ?>">
                <b class="fs-4  d-block text-uppercase logo bg_black p-2 px-3"> <span>
                <img class="img-fluid m-2" style="width: 8%" src="<?php echo e(asset('image/logo_konawe.png')); ?>" alt="logo"/>
            </span>  PPID Kabupaten Konawe</b>
            </a>
            <button class="navbar-toggler offcanvas-nav-btn  ms-auto me-3" type="button">
                <img src="<?php echo e(Vite::asset('resources/style/image/icons-svg/list.svg')); ?>" width="40" height="40" alt="Open TemplateOnweb website menu"/>
            </button>
            <div class="offcanvas offcanvas-start offcanvas-nav" style="width: 50rem">
                <div class="offcanvas-header shadow">
                    <a class="d-flex text-white" href="<?php echo e(route('home')); ?>">
                        <b class="fs-4  d-block text-uppercase logo"> <img class="me-1" style="width: 8%" src="<?php echo e(asset('image/logo_konawe.png')); ?>"/> PPID Kabupaten Konawe</b>
                    </a>
                    <img src="<?php echo e(Vite::asset('resources/style/image/icons-svg/x.svg')); ?>" width="40" height="40" class="ms-auto" data-bs-dismiss="offcanvas" aria-label="Close" alt="Close TemplateOnweb website menu"/>
                </div>
                <div class="offcanvas-body pt-0 align-items-center">
                    <ul class="navbar-nav align-items-lg-center ms-auto">
                        <li class="nav-item">
                            <a style="font-size: 14px" class="nav-link dropdown-toggle <?php echo e($currentRoute == 'home' ? 'active' : ''); ?>" href="<?php echo e(route('home')); ?>" title="Visit home page">
                                Home
                            </a>
                        </li>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="nav-item <?php echo e($menu->children->count() ? 'dropdown' : ''); ?> drop_border">
                                <a class="nav-link <?php echo e($menu->children->count() ? 'dropdown-toggle' : ''); ?> <?php echo e($currentRoute == $menu->type ? 'active' : ''); ?>"
                                   href="<?php echo e($menu->link); ?>"
                                   id="navbarDropdown<?php echo e($menu->id); ?>"
                                      role="button"
                                   aria-expanded="false"
                                   style="font-size: 14px"
                                   <?php if($menu->children->count()): ?> data-bs-toggle="dropdown" <?php endif; ?>>
                                    <?php echo e(strtoupper($menu->name)); ?> <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($menu->children->count()): ?> <img src="<?php echo e(Vite::asset('resources/style/image/icons-svg/chevron-down.svg')); ?>" width="15" height="15" alt="Submenu open/close icon"> <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </a>

                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($menu->children->count()): ?>
                                    <ul class="dropdown-menu drop_1 shadow" aria-labelledby="navbarDropdown<?php echo e($menu->id); ?>">
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $menu->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><a class="dropdown-item" href="<?php echo e($child->link); ?>"><?php echo e($child->name); ?></a></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    </ul>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </ul>

                </div>
            </div>
        </div>
        </div>
    </nav>
</section>
<?php /**PATH D:\dev\source\kominfo\ppid-konawe\resources\views/layouts/part/header.blade.php ENDPATH**/ ?>